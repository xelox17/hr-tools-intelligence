# Solution Power Platform - URL Monitoring (Outils de Recrutement)

Ce package a ete construit a la main a partir du schema documente des
solutions Dataverse (solution.xml / customizations.xml) et du langage de
definition des flows (Workflow Definition Language) - il n'a PAS ete
exporte depuis un environnement Power Platform reel, faute d'acces a un
tenant depuis cet outil. Verifiez les points ci-dessous avant/juste apres
l'import.

## Contenu

- `solution.xml`, `customizations.xml`, `[Content_Types].xml` : manifeste
  de la solution (non geree), 1 flow + 2 references de connexion.
- `Workflows/53660723-f68c-43b7-8cbb-7dc0a3fecca1.json` : la definition complete du flow
  (declencheur + actions), lisible et modifiable directement en JSON.

## Comportement du flow

1. Declencheur recurrence : tous les jours a 7h00, fuseau Europe/Paris
   (`Romance Standard Time`).
2. Lit toutes les lignes de la table Dataverse `new_outilderecrutements`
   (nom d'affichage "Outil de Recrutement").
3. Pour chaque ligne, un `Scope` isole l'appel HTTP GET sur la colonne
   `new_url`, avec un timeout de 15 secondes (`PT15S`). Le `Scope`
   n'a pas de run-after conditionnel sur erreur : le flow continue meme si
   l'appel HTTP echoue, timeout, ou renvoie un code non-2xx.
4. Une condition apres le Scope teste l'etat de l'appel (`Failed`,
   `TimedOut`) et le code HTTP (< 200 ou >= 300) ; si l'un des deux est
   vrai, l'outil est ajoute a la variable tableau `ErrorList` avec son nom
   (colonne `new_name`), son URL et son code (ou "Pas de reponse /
   timeout" si aucune reponse).
5. A la fin de la boucle, si `ErrorList` contient au moins un element, un
   seul email recapitulatif est envoye via Office 365 Outlook a
   `hr-it@lesaffre.com` (tableau HTML : outil / URL / code). Si `ErrorList`
   est vide, aucune action supplementaire n'est executee.

## A verifier absolument avant l'import (specifique a votre environnement)

Ces trois valeurs sont des hypotheses raisonnables mais DOIVENT etre
confirmees contre votre table reelle avant de considerer le flow fiable :

| Dans le flow | Valeur utilisee | A verifier dans Dataverse |
| --- | --- | --- |
| Nom d'ensemble d'entite (table) | `new_outilderecrutements` | Power Apps > Tables > Outil de Recrutement > Nom au pluriel (certaines tables ont un pluriel non standard) |
| Colonne URL | `new_url` | Nom logique exact de la colonne URL sur la table |
| Colonne nom de l'outil | `new_name` | Nom logique exact de la colonne "nom" (souvent la colonne de nom primaire) |

Si l'un de ces noms differe, ouvrez le flow dans l'editeur Power Automate
apres import et corrigez le dans l'action "List rows" (nom de table) ou
dans les expressions `items('Apply_to_each_tool')?['...']` (nom de
colonne), puis enregistrez.

## Import

1. Power Automate (make.powerautomate.com) > Solutions > Importer une
   solution > choisir `LesaffreURLMonitoring.zip`.
2. A l'ecran des references de connexion, creez ou choisissez une
   connexion Dataverse valide et une connexion Office 365 Outlook valide
   pour les deux references listees.
3. Une fois importe, ouvrez le flow, verifiez le tableau ci-dessus, puis
   activez-le (il est importe a l'etat Active mais Power Automate demande
   parfois une activation manuelle apres la premiere sauvegarde).

## Si l'import de la solution echoue

L'import strict d'une solution Dataverse est sensible au moindre ecart de
schema. En secours, le fichier `Workflows/53660723-f68c-43b7-8cbb-7dc0a3fecca1.json` contient
la definition complete (declencheur + actions) : vous pouvez recreer le
flow a la main dans Power Automate en suivant cette structure (meme noms
d'actions, memes expressions), ce qui reproduit exactement le meme
comportement sans dependre du mecanisme d'import de solution.
